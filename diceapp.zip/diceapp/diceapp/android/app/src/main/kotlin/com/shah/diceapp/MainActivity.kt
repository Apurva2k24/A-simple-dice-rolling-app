package com.shah.diceapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
