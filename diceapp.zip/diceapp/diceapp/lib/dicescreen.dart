import "package:flutter/material.dart";
import "dart:math";

void main() {
  runApp(const dicescreen());
}

class dicescreen extends StatefulWidget {
  const dicescreen({super.key});

  @override
  State<dicescreen> createState() => _dicescreenState();
}

class _dicescreenState extends State<dicescreen> {
  int dice1 = 6;
  int dice2 = 6;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff0F044C),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text("THE SUM OF DICES IS: ${dice1 + dice2}",
              style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors.white70)),
          Row(
            children: [
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Image.asset("images/d${dice1}.png"),
              )),
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Image.asset("images/d${dice2}.png"),
              ))
            ],
          ),
          //SizedBox(
          //  height: 190,
          //  width: 350,
          //  child:
             RawMaterialButton(
              fillColor: Colors.white70,
              onPressed: () {
                setState(() {
            
                  dice1 = Random().nextInt(6)+1;
                  dice2 = Random().nextInt(6)+1;
                });
              },
              child: const Padding(
                padding: EdgeInsets.only(left: 300, right: 300,bottom: 90, top: 90),
                child:  Text(
                  "ROLL DICE",
                  style: TextStyle(color: Color(0xff0F044C)),
                ),
              ),
              
            ),
        //  )
        ],
      ),
    );
  }
}
