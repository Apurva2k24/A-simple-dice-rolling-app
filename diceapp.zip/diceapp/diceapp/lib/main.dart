import "package:diceapp/dicescreen.dart";
import "package:flutter/material.dart";

void main() {
  runApp(const diceapp());
}

class diceapp extends StatelessWidget {
  const diceapp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: dicescreen(),
    );
  }
}
