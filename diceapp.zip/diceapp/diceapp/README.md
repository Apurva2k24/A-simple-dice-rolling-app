its useful to give stateless widget it main.dart as its an entry point we use different dart file for stateful screen 
to ham stateful bwidget dusri file me banaege

ek expanded widget se wrap karne pr jo screen se overflow hota h vo nhi hoga 
lekin hame use padding nhi deni h padding image ko hi deni hoti h to usko alag line me le jaake padding denge 
also in flutter every widget is clickable
also background image ke liye backgroundimage: assetimage("") use hota h jbki sirf image ke liye 
image.asset("") use hota hai

raw material button mostly used hota hai usme onpressed naam ka inbuild function hota hai jisme ( ) isme call kia jaata hai like 
rawmaterialbutton(
    onpressed :  (){

    }
)
aur curly braces me outputs likhte hai
jese print("veugNGTE");

IS RAW MATERIALBUTTON ME onpressed longpressed aur on cursor ka option h 
jisme mandatory onpressed hai 

ham ${} use karke statement me variable daal sakte h jese ham python me %d use karte the like 
dicevalue =4 
pehle likhte the image.asset("images/dice4.png")
ab image.assest("images/dice${dicevalue}.png")
output dono ka same hi hoga

int class ke just neeche define hoge aur @override ke upar


ab jab onpressed ke curly braces me ham jo change karte hai dice ke liye vo build function me integer ko change karna hota hai to vo direct likhne pr nahi hota jese
onpressed : () {
    dice1=3;          BAAR BAAR INT NAHI LIKHNA PADTA QKI VARIABLE BS DEFINE KE TIME ME DATATYPE LIKHTE H USKA
    dice2=5;              YE GAALAT HAI
}

HAM USE KARTE HAI SET STATE FUNCTION KA JO BUILD FUNCTION FIRSE CALL KARTA HAI JESE 
onpressed: (){
    sertState( () {     BINA SET STATE KE RELOAD NAHI HOGI PURI SCREEN QKI BUILD FUNCTION FIRSE CALL HI NAHI HOGA
         dice1=6;       BAAR BAAR INT NAHI LIKHNA PADTA QKI VARIABLE BS DEFINE KE TIME ME DATATYPE LIKHTE H USKA
         dice2=3;       YE SWAHI WALA HAI 
    }

    )
}


last me hamne bs dart: math ko import karwaya
jisme ek random() karke function h jiske sath hamne nextInt function lagaya jiska mtlb range jesa hai jisme 0 bhi include hota  hai aur jo no hamne likha hai vo nahi aata vo max no. hota hai to hamne uske liye usme +1 le liya jisse max no bhi aa jae aur 0 bhi naa aaye 

aur fir vo int value set state me daaldi aur vo int value se ham ${<value>} daalke ham photos ke paas le gye jese photo save hai d2 se
int  2 hai to 
dice1=2;
image.asset(images/d${dice1}.png)
aisa

to vo random ka syntax tha aisa 
dice1 = Random().nextInt(6)+1;
iska mtlb h 6 include nahi tha aur 0 bhi aa rha tha to +1 laga diya hamne next int ki range thi maximum 6 mtlb 0 to 5 to +1 laga diya to range modify hoke ho gyi 1 to 6 jo hame dice ke liye chahiye thi 


button ka size badhane ke ab 3 tarike hai 
1 container me daal do aur height aur width daalo 
2 sizedbox me daalke height aur width dalo
3 button me jo text diya hai usko padding karo pure button ko padding karne pr kuch result nahi aaya
text ki padding se button ka size aone aap badta h 
also padding jo widget hai usse start hota hai jese top 30 to text se jaayega top tk 30 top se text tak nahi hoga 
